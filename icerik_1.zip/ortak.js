/* Ortak: ziyaretçi analizi (GoatCounter) ve e-bülten kutusu — ayarlar yönetici panelinden gelir */
(function () {
  var me = document.querySelector('script[src$="ortak.js"]'), BASE = me ? me.src.replace(/ortak\.js.*$/, '') : '';
  function all(sel) { return [].slice.call(document.querySelectorAll(sel)); }
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  fetch(BASE + 'icerik/ayarlar.json?v=' + Date.now()).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; }).then(function (S) {
    S = S || {};
    // ---- analiz (çerezsiz GoatCounter); "Do Not Track" açıksa sayılmaz ----
    var gc = String(S.analytics && S.analytics.goatcounter || '').trim().toLowerCase(), gcOn = /^[a-z0-9][a-z0-9-]{1,}$/.test(gc);
    if (gcOn && navigator.doNotTrack !== '1' && !/^(localhost|127\.)/.test(location.hostname)) {
      window.goatcounter = { path: function () { return location.pathname + location.search; } };
      var sc = document.createElement('script'); sc.async = true; sc.src = 'https://gc.zgo.at/count.js'; sc.setAttribute('data-goatcounter', 'https://' + gc + '.goatcounter.com/count'); document.head.appendChild(sc);
    }
    all('[data-only="analytics"]').forEach(function (e) { e.hidden = !gcOn; });
    all('[data-only="noanalytics"]').forEach(function (e) { e.hidden = gcOn; });
    // ---- e-bülten ----
    var nl = S.newsletter || {}, bd = String(nl.buttondown || '').trim(), url = String(nl.url || '').trim(), okBd = /^[A-Za-z0-9_.-]{2,}$/.test(bd), okUrl = /^https:\/\//i.test(url);
    all('[data-only="newsletter"]').forEach(function (e) { e.hidden = !(okBd || okUrl); });
    all('#bulten').forEach(function (host) {
      if (!(okBd || okUrl)) { host.hidden = true; return; }
      host.textContent = ''; host.hidden = false;
      var box = el('div', 'news-box');
      box.appendChild(el('h2', null, nl.title || 'Yeni konulardan haberdar ol'));
      box.appendChild(el('p', null, nl.text || 'Yeni simülasyonlar, konu anlatımları ve duyurular için e-posta listesine katıl. İstediğin zaman ayrılabilirsin.'));
      if (okBd) {
        var f = el('form', 'news-form'); f.action = 'https://buttondown.com/api/emails/embed-subscribe/' + encodeURIComponent(bd); f.method = 'post'; f.target = 'popupwindow';
        var inp = el('input'); inp.type = 'email'; inp.name = 'email'; inp.required = true; inp.placeholder = 'E-posta adresin'; inp.setAttribute('aria-label', 'E-posta adresi');
        var btn = el('button', 'news-btn', 'Abone ol'); btn.type = 'submit';
        f.appendChild(inp); f.appendChild(btn);
        f.addEventListener('submit', function () { window.open('https://buttondown.com/' + encodeURIComponent(bd), 'popupwindow'); });
        box.appendChild(f);
      } else {
        var a = el('a', 'news-btn', 'Abone ol'); a.href = url; a.target = '_blank'; a.rel = 'noopener'; box.appendChild(a);
      }
      box.appendChild(el('p', 'news-note', 'E-posta adresin yalnızca bülten göndermek için kullanılır.'));
      host.appendChild(box);
    });
  });
})();
