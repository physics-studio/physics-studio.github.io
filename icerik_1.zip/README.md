# Physics.Studio

Etkileşimli fizik simülasyonları (@physics.studio0).

- `index.html`: ana sayfa
- `izle.html?konu=<anahtar>`: simülasyonlar
- `admin.html`: yönetici paneli
