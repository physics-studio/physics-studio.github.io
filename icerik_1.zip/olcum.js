/* Physics.Studio etkileşim ölçümü (Google Analytics olayları). Çerez onayı Consent Mode ile yönetilir. */
(function () {
  function ev(n, p) { try { if (window.gtag) window.gtag('event', n, p || {}); } catch (e) {} }
  window.psEv = ev;
  var path = location.pathname, sayfa = /\/test\.html$/.test(path) ? 'test' : /\/sorular\//.test(path) ? 'soru_sayfasi' : /\/konu\//.test(path) ? 'konu_sayfasi' : /\/izle\.html$/.test(path) ? 'simulasyon' : 'diger';
  var konuYol = (path.match(/\/(?:sorular|konu|unite)\/([^\/.]+)\.html$/) || [])[1] || '';
  // simülasyon açıldı (izle.html: her konu yüklenişinde)
  if (sayfa === 'simulasyon') {
    var fr = document.querySelector('iframe'), son = '';
    if (fr) fr.addEventListener('load', function () { var k = new URLSearchParams(location.search).get('konu') || ''; if (k && k !== son) { son = k; ev('sim_ac', { konu: k }); } });
  }
  // soru cevaplama (soru sayfaları, konu sayfası quizi, karışık test, günün sorusu)
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('.qopt'); if (!b || b.disabled) return;
    var kap = b.closest('.qcard') || b.closest('#gunun'); if (!kap || kap.classList.contains('done')) return;
    var yer = b.closest('#gunun') ? 'gunun_sorusu' : sayfa, k = kap.getAttribute('data-k') || konuYol;
    if (yer === 'gunun_sorusu') { var a = kap.querySelector('a[href*="sorular/"]'); k = a ? (a.getAttribute('href').match(/sorular\/([^.]+)\.html/) || [])[1] || '' : ''; }
    var secim = b.getAttribute('data-i');
    setTimeout(function () { var ok = kap.querySelector('.qopt.ok'); if (!ok) return; ev('soru_cevap', { konu: k, yer: yer, dogru: ok.getAttribute('data-i') === secim ? 'evet' : 'hayir' }); }, 0);
  }, true);
  // test başladı / bitti
  document.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('#tGo')) setTimeout(function () { if (document.querySelector('.tst-q')) ev('test_basla', { soru_sayisi: document.querySelectorAll('.tst-q').length ? (document.querySelector('.tst-top span') || {}).textContent.replace(/.*\/\s*/, '') : '' }); }, 0); });
  if (sayfa === 'test') new MutationObserver(function () { var r = document.querySelector('.tst-res:not([data-olc])'); if (!r) return; r.setAttribute('data-olc', '1'); var s = r.querySelector('.tst-score'); var m = s ? s.textContent.match(/(\d+)\s*\/\s*(\d+)/) : null; ev('test_bitir', m ? { dogru: +m[1], toplam: +m[2], yuzde: Math.round(100 * m[1] / m[2]) } : {}); }).observe(document.body, { childList: true, subtree: true });
  // paylaşım, hata bildirimi, iletişim
  document.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target : null; if (!t) return;
    var sh = t.closest('[data-share]'); if (sh) ev('paylas', { yontem: sh.getAttribute('data-share'), konu: konuYol });
    if (t.closest('.qrep, a[data-hata]')) ev('hata_bildir', { konu: konuYol || sayfa });
    var so = t.closest('a[href*="tiktok.com"], a[href*="instagram.com"], a[href*="youtube.com"]'); if (so) ev('sosyal_tikla', { platform: /tiktok/.test(so.href) ? 'tiktok' : /instagram/.test(so.href) ? 'instagram' : 'youtube' });
  });
  var f = document.getElementById('cform'); if (f) f.addEventListener('submit', function () { var s = f.querySelector('#konu'); ev('iletisim_gonder', { konu: s ? s.value : '' }); });
})();
