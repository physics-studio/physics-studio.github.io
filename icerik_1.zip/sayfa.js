/* Alt sayfalar: yönetici panelindeki iletişim e-postası, "Hakkında" yazısı ve hesap bağlantıları */
(function () {
  var BASE = (document.currentScript && document.currentScript.src || '').replace(/sayfa\.js.*$/, '');
  function getJson(u) { return fetch(BASE + u + '?v=' + Date.now()).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; }); }
  function all(sel) { return [].slice.call(document.querySelectorAll(sel)); }
  getJson('icerik/ayarlar.json').then(function (S) {
    S = S || {};
    var email = (S.contact && S.contact.email || '').trim();
    all('[data-fill="email"]').forEach(function (a) { if (email) { a.textContent = email; a.href = 'mailto:' + email; } a.hidden = !email; });
    all('[data-only="email"]').forEach(function (e) { e.hidden = !email; });
    all('[data-only="noemail"]').forEach(function (e) { e.hidden = !!email; });
    var about = (S.about || '').trim(), ab = document.querySelector('[data-fill="about"]');
    if (about && ab) { ab.textContent = ''; about.split(/\n{2,}/).forEach(function (p) { var el = document.createElement('p'); el.textContent = p.replace(/\n/g, ' '); ab.appendChild(el); }); }
    all('[data-social]').forEach(function (a) { var v = S.social && S.social[a.getAttribute('data-social')]; if (v) a.href = v; if (S.social && S.social[a.getAttribute('data-social')] === '') a.hidden = true; });
    var form = document.getElementById('cform');
    if (form && email) form.addEventListener('submit', function (e) {
      e.preventDefault();
      var f = new FormData(form), subj = '[Physics.Studio] ' + (f.get('konu') || 'Mesaj'), body = (f.get('mesaj') || '') + '\n\n— ' + (f.get('ad') || '');
      window.location.href = 'mailto:' + email + '?subject=' + encodeURIComponent(subj) + '&body=' + encodeURIComponent(body);
    });
    var fl = S.footer; if (fl != null) { var el = document.querySelector('.pfooter .fline'); if (el && fl) el.textContent = fl; }
  });
  // paylaş düğmeleri (konu sayfaları)
  all('[data-share]').forEach(function (b) {
    var type = b.getAttribute('data-share');
    if (type === 'native' && !navigator.share) { b.hidden = true; return; }
    b.addEventListener('click', function () {
      var url = location.href.split('#')[0], title = document.title;
      if (type === 'wa') window.open('https://wa.me/?text=' + encodeURIComponent(title + ' ' + url), '_blank', 'noopener');
      else if (type === 'x') window.open('https://twitter.com/intent/tweet?text=' + encodeURIComponent(title) + '&url=' + encodeURIComponent(url), '_blank', 'noopener');
      else if (type === 'native') { navigator.share({ title: title, url: url }).catch(function () {}); }
      else if (type === 'copy') {
        var done = function () { var o = b.textContent; b.textContent = 'Kopyalandı ✓'; setTimeout(function () { b.textContent = o; }, 1800); };
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(url).then(done, function () { window.prompt('Bağlantıyı kopyala:', url); });
        else window.prompt('Bağlantıyı kopyala:', url);
      }
    });
  });
})();
/* hata-bildir:bas */
(function () {
  var BASE = (document.currentScript && document.currentScript.src || '').replace(/sayfa\.js.*$/, '');
  function baslik() { var e = document.querySelector('main h1'); var t = e ? e.cloneNode(true) : null; if (t) [].forEach.call(t.querySelectorAll('.rzs'), function (x) { x.remove(); }); return t ? t.textContent.trim() : document.title.split('·')[0].trim(); }
  function ekle(card) {
    var hd = card.querySelector('.qhead'); if (!hd || hd.querySelector('.qrep')) return;
    var yer, adres;
    if (card.dataset.k) { yer = ((card.querySelector('.qno') || {}).textContent || card.dataset.k).trim() + ' · Soru ' + card.dataset.i; adres = 'sorular/' + card.dataset.k + '.html#s' + card.dataset.i; }
    else { yer = baslik() + ' · ' + ((card.querySelector('.qno') || {}).textContent || '').trim(); adres = location.pathname.replace(/^\//, '') + (card.id ? '#' + card.id : ''); }
    var a = document.createElement('a'); a.className = 'qrep'; a.textContent = 'Hata bildir'; a.title = 'Bu soruda hata gördüysen bildir';
    a.href = BASE + 'iletisim.html?hata=' + encodeURIComponent(yer) + '&adres=' + encodeURIComponent(adres);
    var w = document.createElement('span'); w.className = 'qhead-r'; var hb = hd.querySelector('.qhint-btn'); w.appendChild(a); if (hb) w.appendChild(hb); hd.appendChild(w);
  }
  function tara() { [].forEach.call(document.querySelectorAll('.qcard'), ekle); }
  tara(); if (document.getElementById('tst') || document.querySelector('.tst-q, [data-test]') || /test\.html/.test(location.pathname)) new MutationObserver(tara).observe(document.body, { childList: true, subtree: true });
  [].forEach.call(document.querySelectorAll('a[data-hata]'), function (a) { a.href = BASE + 'iletisim.html?hata=' + encodeURIComponent(baslik()) + '&adres=' + encodeURIComponent(location.pathname.replace(/^\//, '')); });
  var f = document.getElementById('cform'), q = new URLSearchParams(location.search);
  if (f && q.get('hata')) {
    var s = f.querySelector('#konu'); if (s) s.value = 'Hata bildirimi';
    var m = f.querySelector('#mesaj'); if (m && !m.value) m.value = 'Yer: ' + q.get('hata') + '\nAdres: ' + location.origin + '/' + (q.get('adres') || '') + '\n\nHata ne? (yanlış cevap, yazım hatası, çizim hatası...):\n';
    var bx = document.createElement('p'); bx.className = 'hata-not'; bx.textContent = 'Hata bildirimi formu hazır: hangi soruda olduğunu ekledik, sen sadece hatayı kısaca yaz.'; f.insertBefore(bx, f.firstChild);
    if (m) m.style.minHeight = '200px';
    setTimeout(function () { if (m) { m.focus({ preventScroll: true }); m.setSelectionRange(m.value.length, m.value.length); m.scrollTop = 0; } window.scrollTo({ top: bx.getBoundingClientRect().top + scrollY - 90, behavior: 'smooth' }); }, 150);
  }
})();
/* hata-bildir:son */
